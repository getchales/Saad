"use strict";
/*The result is an error.
The function sayHi is declared inside the if, 
so it only lives inside it. There is no sayHi outside.
But it works in the onsole...
*/

let phrase = "Hello";
if (true) {
  let user = "John";
  function sayHi() {
    alert(`${phrase}, ${user}`);
  }
}
sayHi();