"use strict";
function sum(a) {

  return function(b) {
    return a + b; // takes "a" from the outer lexical environment
  };

}

alert( sum(2)(3) ); // 5
alert( sum(5)(1) ); // 6