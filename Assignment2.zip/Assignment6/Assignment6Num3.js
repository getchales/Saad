"use strict";
/*the formula is the fastest solution.
 It uses only 3 operations for any number n*/
function sumTo(n) {
    return n * (n + 1) / 2;
  }
  
  alert( sumTo(100) );