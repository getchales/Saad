"use strict";
/*
The loop variant is the second in terms of speed. 
In both the recursive and the loop variant 
we sum the same numbers.But the recursion involves 
nested calls and execution stack management. 
That also takes resources, so it’s slower.
*/
function sumTo(n){
    let sum = 0;
for(let i=1;i<=n;i++){
sum+=i;
}
return sum;
}
sumTo(100);