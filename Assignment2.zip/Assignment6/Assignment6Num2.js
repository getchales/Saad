"use strict";
/*
The loop variant is the second in terms of speed. 
In both the recursive and the loop variant 
we sum the same numbers.But the recursion involves 
nested calls and execution stack management. 
That also takes resources, so it’s slower.
*/
function sumTo(n){
    if(n==1){
return 1;
    }
return n+sumTo(n-1);
}
sumTo(100);