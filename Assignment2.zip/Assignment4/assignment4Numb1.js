"use strict";
let str = "Hello";

str.test = 5;

alert(str.test); //Error: Cannot create property 'test' on string 'Hello'
