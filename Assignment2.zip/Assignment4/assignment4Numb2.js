"use strict";
let a = +prompt("The first number?", "");
let b = +prompt("The second number?", "");

alert(a + b);
