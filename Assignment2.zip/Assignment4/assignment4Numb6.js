"use strict";
/**
 * @param  {maximum numbers} min
 * @param  {minimum numbers} max
 */
function randomInteger(min, max) {
  // now rand is from  (min-0.5) to (max+0.5)
  let rand = min - 0.5 + Math.random() * (max - min + 1);
  return Math.round(rand);
}
alert(randomInteger(1, 3));
