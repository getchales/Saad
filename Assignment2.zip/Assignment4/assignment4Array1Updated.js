"use strict";
/**
 * @param  {string} str
 */
let str = "my-long-word";
function camelize(str) {
  return str
    .split('-') // splits 'my-long-word' into array ['my', 'long', 'word']
    .map((word, index) => index == 0 ? word : word[0].toUpperCase() + word.slice(1))
      // capitalizes first letters of all array items except the first one
      // converts ['my', 'long', 'word'] into ['my', 'Long', 'Word']
      
    .join(''); // joins ['my', 'Long', 'Word'] into 'myLongWord'
}
document.write(camelize(str));