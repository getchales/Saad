"use strict";
/**
 * @param  {minimum number} min
 * @param  {maximum numbers} max
 */
function random(min, max) {
  return min + Math.random() * (max - min);
}

alert(random(1, 5));
alert(random(1, 5));
alert(random(1, 5));
