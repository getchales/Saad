"use strict";
/**
 * @param  {string} str
 */
function extractCurrencyValue(str) {
  return +str.slice(1);
}
