"use strict";
/**
 * @param  {} anArray
 * @param  {} {letlongestWord="";for(leti=0;i<anArray.length;i++
 * @param  {} {if(longestWord.length<anArray[i].length
 */
function findLongestWord(anArray) {
    let longestWord = "";
    for (let i = 0; i < anArray.length; i++) {
      if (longestWord.length < anArray[i].length) {
        longestWord = anArray[i];
      }
    }
    return longestWord.length;
  }