"use strict";
/**
 * @param  {} anArray
 * @param  {} n
 * @param  {} {letnewArray=[];letj=0;for(leti=0;i<anArray.length;i++
 * @param  {} {if(anArray[i].length>n
 */
function filterLongWords(anArray, n) {
    let newArray = [];
    let j = 0;
    for (let i = 0; i < anArray.length; i++) {
      if (anArray[i].length > n) {
        newArray[j] = anArray[i];
        j++;
      }
    }
    return newArray;
  }