/**
 * @param  {} anArray
 * @param  {} {letsumOfNumbers=0;for(leti=0;i<anArray.length;i++
 * @param  {} {sumOfNumbers+=anArray[i];}returnsumOfNumbers;}functionmultiply(anArray
 * @param  {} {letmultiplicationOfNumbers=1;for(leti=0;i<anArray.length;i++
 */"use strict";
function sum(anArray) {
    let sumOfNumbers = 0;
    for (let i = 0; i < anArray.length; i++) {
      sumOfNumbers += anArray[i];
    }
    return sumOfNumbers;
  }
  function multiply(anArray) {
    let multiplicationOfNumbers = 1;
    for (let i = 0; i < anArray.length; i++) {
      multiplicationOfNumbers *= anArray[i];
    }
    return multiplicationOfNumbers;
  }