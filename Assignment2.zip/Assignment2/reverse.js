"use strict";
/**
 * @param  {} str
 * @param  {} {returnstr.split(""
 * @param  {} .reverse(
 * @param  {} .join(""
 */
function reverse(str) {
    return str
      .split("")
      .reverse()
      .join("");
  }