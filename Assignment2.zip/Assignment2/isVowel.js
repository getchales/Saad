"use strict";
/**
 * @param  {} x
 * @param  {} {if(x=="a"||x=="e"||x=="i"||x=="o"||x=="u"
 */
function isVowel(x) {
    if (x == "a" || x == "e" || x == "i" || x == "o" || x == "u") {
      result = true;
    } else {
      result = false;
    }
    return result;
  }