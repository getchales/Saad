"use strict";
/**
 * @param  {} {returnthis.a+this.b;}
 * @param  {} mul(
 * @param  {} {returnthis.a*this.b;}
 * @param  {} read(
 * @param  {} {this.a=+prompt("a?"
 * @param  {} 0
 * @param  {} ;this.b=+prompt("b?"
 * @param  {} 0
 * @param  {} ;}};calculator.read(
 * @param  {} ;alert(calculator.sum(
 * @param  {} ;alert(calculator.mul(
 */

let calculator = {
  sum() {
    return this.abc + this.bcd;
  },

  mul() {
    return this.abc * this.bcd;
  },

  read() {
    this.abc = +prompt("a?", 0);
    this.bcd = +prompt("b?", 0);
  }
};

calculator.read();
alert(calculator.sum());
alert(calculator.mul());
