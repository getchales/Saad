"use strict";
/**
 * @param  {} {alert(this.name
 * @param  {} }}(user.go
 * @param  {} (
 */
let user = {
  name: "John",
  go: function() {
    alert(this.name);
  }
}(user.go)(); // error!
