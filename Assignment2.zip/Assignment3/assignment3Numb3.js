"use strict";

const user = {
  name: "John"
};

// it works
user.name = "Pete";

// but no for location
user = 123;
