"use strict";
/**
 * @param  {} {this.step++;returnthis;}
 * @param  {} down(
 * @param  {} {this.step--;returnthis;}
 * @param  {} showStep(
 * @param  {} {alert(this.step
 * @param  {} ;returnthis;}}ladder.upp(
 * @param  {} .upp(
 * @param  {} .down(
 * @param  {} .upp(
 * @param  {} .down(
 * @param  {} .showStep(
 */
let ladder = {
  step: 0,
  upp() {
    this.step++;
    return this;
  },
  down() {
    this.step--;
    return this;
  },
  showStep() {
    alert( this.step );
    return this;
  }
}

ladder.upp().upp().down().upp().down().showStep(); // 1