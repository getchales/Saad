"use strict";

/**
 *
 */

let library = [
  { title: "The Road Ahead", 
  author: "Bill Gates", 
  libraryID: 1254 }
];
function makeBook(title,author,id){
    let book ={
        title:title,
        author:author,
        libraryID:id
    }
    return book;
};

document.getElementById("addBookButton").onclick = function(){
    let title= document.getElementById("titleInput");
    let author =document.getElementById("authorInput");
    let book = makeBook(title,author);
    library.push(book);

let pro=title+" "+author;
document.getElementById("outPut").innerHTML=pro;
};