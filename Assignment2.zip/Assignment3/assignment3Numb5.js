"use strict";
/**
 * @param  {} obj
 * @param  {} {for(letkeyinobj
 * @param  {} {if(typeofobj[key]=="number"
 */
function multiplyNumeric(obj) {
  for (let key in obj) {
    if (typeof obj[key] == "number") {
      obj[key] *= 2;
    }
  }
}
