"use strict";
/**
 * @param  {} {returnobj;}functionB(
 * @param  {} {returnobj;}alert(newA(
 * @param  {} ==newB(
 */
let obj = {};
function A() { return obj; }
function B() { return obj; }

alert( new A() == new B() ); // true