"use strict";
/**
 * @param  {} {this.read=function(
 * @param  {} {this.a=+prompt('a?'
 * @param  {} 0
 * @param  {} ;this.b=+prompt('b?'
 * @param  {} 0
 * @param  {} ;};this.sum=function(
 * @param  {} {returnthis.a+this.b;};this.mul=function(
 * @param  {} {returnthis.a*this.b;};}letcalculator=newCalculator(
 * @param  {} ;calculator.read(
 * @param  {} ;alert("Sum="+calculator.sum(
 * @param  {} ;alert("Mul="+calculator.mul(
 */
function Calculator() {

  this.read = function() {
    this.a = +prompt('a?', 0);
    this.b = +prompt('b?', 0);
  };

  this.sum = function() {
    return this.a + this.b;
  };

  this.mul = function() {
    return this.a * this.b;
  };
}

let calculator = new Calculator();
calculator.read();

alert( "Sum=" + calculator.sum() );
alert( "Mul=" + calculator.mul() );