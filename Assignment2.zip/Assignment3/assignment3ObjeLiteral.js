"use strict";
/**
 * @param  {"John"} {return{name
 * @param  {this};};letuser=makeUser(} ref
 */
function makeUser() {
  return {
    name: "John",
    ref: this
  };
};

let user = makeUser();

alert( user.ref.name ); // Error: Cannot read property 'name' of undefined